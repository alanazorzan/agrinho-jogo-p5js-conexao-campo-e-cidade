// --- Variáveis globais ---

let tela = 'start'; // start, introducao, instrucoes, campo, cidade, gameover, vitoria

let botaoStart, botaoInstrucoes, botaoVoltar, botaoPularIntroducao, botaoIrCidade,
    botaoTrocar, botaoComprarMelhoriaCampo, botaoComprarMelhoriaCidade,
    botaoComprarFerramentas, botaoComprarGasolina, botaoReiniciarJogo;

let trator;

let recursos = { vegetais: 0, frutas: 0, madeira: 0, dinheiro: 0 };
let vidas = 3;
let obstaculos = [];
let coletaveis = [];
let maxObstaculos = 3; // Mantido para referência, mas a geração ajusta dinamicamente

let campoNivel = 1;
let cidadeNivel = 1;

// Variável única para mensagens na cidade
let mensagemCidadeStatus = '';

let ferramentas = 10; // Ferramentas iniciais
let gasolina = 10; // Gasolina inicial
const CUSTO_FERRAMENTA = 30; // Custo para comprar ferramentas (MAIS BARATO!)
const CUSTO_GASOLINA = 25; // Custo para comprar gasolina (MAIS BARATO!)

// Animação da introdução
let introTexto = [
  "No coração do Vale Verde, a vida floresce na harmonia entre o campo e a cidade.",
  "O campo, com suas vastas plantações e florestas, nutre a cidade com seus preciosos recursos.",
  "E a cidade, com sua inovação e tecnologia, provê o campo com as ferramentas para prosperar.",
  "Você é o elo dessa conexão vital, controlando seu trator para colher, entregar e construir um futuro melhor.",
  "Mantenha o equilíbrio, cuide da sua terra e da sua gente, e observe o Vale Verde florescer!"
];
let introIndex = 0;
let introAlpha = 0;
let introFadeIn = true;
let introTimer = 0;
const INTRO_DURACAO_TEXTO = 360; // Aumentado para 6 segundos por frase (60 frames/seg * 6)
const FADE_SPEED = 4; // Velocidade do fade-in/out. Menor = mais suave/lento.

// Animação de coleta na cidade
let animacaoColetaCidadeAtiva = false;
let tipoColetaCidade = '';
let coletavelCidadeX, coletavelCidadeY;
let animacaoColetaCidadeTimer = 0;
const DURACAO_ANIMACAO_COLETA = 60; // Frames

// --- NOVAS VARIAVEIS ---
// Animação Nível Up
let animacaoNivelAtiva = false;
let animacaoNivelTexto = '';
let animacaoNivelAlpha = 0;
let animacaoNivelTimer = 0;
const DURACAO_ANIMACAO_NIVEL = 120; // 2 segundos (60 frames/seg * 2)

// Mini-missões
let missaoAtiva = false;
let tipoMissao = ''; // 'vegetais', 'frutas', 'madeira'
let quantidadeMissao = 0;
let quantidadeAtualMissao = 0;
let recompensaMissao = 0;
let mensagemMissao = '';

// Sistema de Clima
let climaAtual = 'sol'; // 'sol', 'chuva'
let timerClima = 0;
const DURACAO_CLIMA = 60 * 30; // 30 segundos de duração para cada clima (60 frames/seg * 30)
const FATOR_CHUVA_TRATOR = 0.7; // Reduz a velocidade do trator em 30% na chuva
const FATOR_SOL_COLETA = 0.8; // Acelera a geração de coletáveis (intervalo menor)

// Sons - AGORA DESATIVADOS PARA EVITAR ERROS 404
let somColeta;
let somColisao;
let somCompra;

// --- PRELOAD (carrega assets antes do setup) ---
function preload() {
  // Sons agora são objetos "mudos" para evitar erros de carregamento
  somColeta = { play: () => {}, setVolume: () => {} };
  somColisao = { play: () => {}, setVolume: () => {} };
  somCompra = { play: () => {}, setVolume: () => {} };
}

// --- SETUP ---
function setup() {
  // Ajusta o canvas para o tamanho da janela
  createCanvas(windowWidth, windowHeight);
  textFont('Arial');

  // Criar botões da start screen
  botaoStart = createButton('Iniciar Jogo');
  botaoStart.position(width / 2 - 60, height / 2);
  botaoStart.style('padding', '10px 20px');
  botaoStart.style('font-size', '18px');
  botaoStart.style('background-color', '#A4D4AE');
  botaoStart.style('border', 'none');
  botaoStart.style('border-radius', '8px');
  botaoStart.mousePressed(() => {
    tela = 'introducao';
    esconderBotoesStart();
    botaoPularIntroducao.show();
    reiniciarIntroducao();
  });

  botaoInstrucoes = createButton('Instruções');
  botaoInstrucoes.position(width / 2 - 50, height / 2 + 50);
  botaoInstrucoes.style('padding', '8px 20px');
  botaoInstrucoes.style('font-size', '16px');
  botaoInstrucoes.style('background-color', '#D9EAD3');
  botaoInstrucoes.style('border', 'none');
  botaoInstrucoes.style('border-radius', '8px');
  botaoInstrucoes.mousePressed(() => {
    tela = 'instrucoes';
    esconderBotoesStart();
    botaoVoltar.show();
  });

  // Botão para pular introdução
  botaoPularIntroducao = createButton('Pular Introdução');
  botaoPularIntroducao.position(width - 150, 20);
  botaoPularIntroducao.style('padding', '6px 15px');
  botaoPularIntroducao.style('font-size', '14px');
  botaoPularIntroducao.style('background-color', '#C9DFC9');
  botaoPularIntroducao.style('border', 'none');
  botaoPularIntroducao.style('border-radius', '6px');
  botaoPularIntroducao.mousePressed(() => {
    tela = 'campo';
    esconderBotoesIntroducao();
    resetJogo(); // Reseta o jogo e inicia o campo
    botaoIrCidade.show(); // Mostra o botão Ir para Cidade
  });
  botaoPularIntroducao.hide();

  // Botão para voltar das instruções e da cidade
  botaoVoltar = createButton('Voltar');
  botaoVoltar.position(20, 20);
  botaoVoltar.style('padding', '6px 15px');
  botaoVoltar.style('font-size', '14px');
  botaoVoltar.style('background-color', '#C9DFC9');
  botaoVoltar.style('border', 'none');
  botaoVoltar.style('border-radius', '6px');
  botaoVoltar.mousePressed(() => {
    if (tela === 'instrucoes') {
      tela = 'start';
      botaoVoltar.hide();
      mostrarBotoesStart();
    } else if (tela === 'cidade') {
      tela = 'campo';
      esconderBotoesCidade();
      botaoIrCidade.show(); // Mostra o botão de ir pra cidade novamente
    }
    mensagemCidadeStatus = ''; // Limpa a mensagem ao voltar
  });
  botaoVoltar.hide();

  // Botão para ir para cidade no campo
  botaoIrCidade = createButton('Ir para Cidade');
  botaoIrCidade.position(width - 140, 20);
  botaoIrCidade.style('padding', '8px 15px');
  botaoIrCidade.style('font-size', '14px');
  botaoIrCidade.style('background-color', '#B0CFC4');
  botaoIrCidade.style('border', 'none');
  botaoIrCidade.style('border-radius', '8px');
  botaoIrCidade.mousePressed(() => {
    tela = 'cidade';
    mensagemCidadeStatus = ''; // Limpa a mensagem ao entrar na cidade
    esconderBotoesCampo();
    mostrarBotoesCidade();
  });
  botaoIrCidade.hide();

  // Botão para trocar recursos na cidade
  botaoTrocar = createButton('Trocar Recursos');
  botaoTrocar.position(width / 2 - 100, height * 0.6); // Posicionamento mais organizado
  botaoTrocar.style('padding', '8px 15px');
  botaoTrocar.style('font-size', '14px');
  botaoTrocar.style('background-color', '#A9C3B8');
  botaoTrocar.style('border', 'none');
  botaoTrocar.style('border-radius', '8px');
  botaoTrocar.mousePressed(() => {
    trocarRecursos();
  });
  botaoTrocar.hide();

  // Botões para comprar melhorias
  botaoComprarMelhoriaCampo = createButton('Melhorar Campo');
  botaoComprarMelhoriaCampo.position(width / 2 - 100, height * 0.6 + 50);
  botaoComprarMelhoriaCampo.style('padding', '8px 15px');
  botaoComprarMelhoriaCampo.style('font-size', '14px');
  botaoComprarMelhoriaCampo.style('background-color', '#A9C3B8');
  botaoComprarMelhoriaCampo.style('border', 'none');
  botaoComprarMelhoriaCampo.style('border-radius', '8px');
  botaoComprarMelhoriaCampo.mousePressed(() => {
    comprarMelhoria('campo');
  });
  botaoComprarMelhoriaCampo.hide();

  botaoComprarMelhoriaCidade = createButton('Melhorar Cidade');
  botaoComprarMelhoriaCidade.position(width / 2 - 100, height * 0.6 + 100);
  botaoComprarMelhoriaCidade.style('padding', '8px 15px');
  botaoComprarMelhoriaCidade.style('font-size', '14px');
  botaoComprarMelhoriaCidade.style('background-color', '#A9C3B8');
  botaoComprarMelhoriaCidade.style('border', 'none');
  botaoComprarMelhoriaCidade.style('border-radius', '8px');
  botaoComprarMelhoriaCidade.mousePressed(() => {
    comprarMelhoria('cidade');
  });
  botaoComprarMelhoriaCidade.hide();

  // Botões para comprar suprimentos
  // Atualizado para incluir o custo fixo no texto
  botaoComprarFerramentas = createButton(`Comprar Ferramentas ($${CUSTO_FERRAMENTA})`);
  botaoComprarFerramentas.position(width * 0.05, height * 0.6 + 50); // Posicionamento mais à esquerda
  botaoComprarFerramentas.style('padding', '8px 15px');
  botaoComprarFerramentas.style('font-size', '14px');
  botaoComprarFerramentas.style('background-color', '#A9C3B8');
  botaoComprarFerramentas.style('border', 'none');
  botaoComprarFerramentas.style('border-radius', '8px');
  botaoComprarFerramentas.mousePressed(() => {
    comprarSuprimento('ferramentas');
  });
  botaoComprarFerramentas.hide();

  botaoComprarGasolina = createButton(`Comprar Gasolina ($${CUSTO_GASOLINA})`);
  botaoComprarGasolina.position(width * 0.05, height * 0.6 + 100); // Posicionamento mais à esquerda
  botaoComprarGasolina.style('padding', '8px 15px');
  botaoComprarGasolina.style('font-size', '14px');
  botaoComprarGasolina.style('background-color', '#A9C3B8');
  botaoComprarGasolina.style('border', 'none');
  botaoComprarGasolina.style('border-radius', '8px');
  botaoComprarGasolina.mousePressed(() => {
    comprarSuprimento('gasolina');
  });
  botaoComprarGasolina.hide();

  // Botão de Reiniciar Jogo (para Game Over e Vitória)
  botaoReiniciarJogo = createButton('Voltar ao Início');
  botaoReiniciarJogo.position(width / 2 - 70, height / 2 + 80);
  botaoReiniciarJogo.style('padding', '10px 20px');
  botaoReiniciarJogo.style('font-size', '18px');
  botaoReiniciarJogo.style('background-color', '#A4D4AE');
  botaoReiniciarJogo.style('border', 'none');
  botaoReiniciarJogo.style('border-radius', '8px');
  botaoReiniciarJogo.mousePressed(() => {
    tela = 'start';
    resetJogo();
    botaoReiniciarJogo.hide();
    mostrarBotoesStart();
  });
  botaoReiniciarJogo.hide();

  resetJogo();
}

// --- FUNÇÃO PARA REDIMENSIONAR O CANVAS COM A JANELA ---
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  // Reajusta a posição dos botões ao redimensionar a tela
  if (tela === 'start') {
    botaoStart.position(width / 2 - 60, height / 2);
    botaoInstrucoes.position(width / 2 - 50, height / 2 + 50);
  }
  botaoPularIntroducao.position(width - 150, 20);
  botaoVoltar.position(20, 20);
  botaoIrCidade.position(width - 140, 20);
  botaoTrocar.position(width / 2 - 100, height * 0.6);
  // Ajuste de posição para os botões de melhoria para evitar sobreposição com texto de status
  botaoComprarMelhoriaCampo.position(width / 2 - 100, height * 0.6 + 50);
  botaoComprarMelhoriaCidade.position(width / 2 - 100, height * 0.6 + 100);
  botaoComprarFerramentas.position(width * 0.05, height * 0.6 + 50);
  botaoComprarGasolina.position(width * 0.05, height * 0.6 + 100);
  botaoReiniciarJogo.position(width / 2 - 70, height / 2 + 80);

  // Reajusta a posição do trator ao redimensionar (opcional, mas bom para consistência)
  if (trator) {
    trator.x = width / 2 - trator.w / 2;
    trator.y = height * 0.75 - trator.h;
  }
}

// --- FUNÇÕES AUXILIARES DE ESTADO DO JOGO ---
function resetJogo() {
  recursos = { vegetais: 0, frutas: 0, madeira: 0, dinheiro: 0 };
  vidas = 3;
  obstaculos = [];
  coletaveis = [];
  campoNivel = 1;
  cidadeNivel = 1;
  mensagemCidadeStatus = ''; // Limpa a mensagem da cidade
  ferramentas = 10;
  gasolina = 10;
  trator = new Trator(); // Reinicia o trator
  esconderBotoesCidade();
  esconderBotoesIntroducao();
  esconderBotoesCampo();
  botaoReiniciarJogo.hide();

  // Reinicia as variáveis de clima
  climaAtual = 'sol';
  timerClima = 0;

  // Inicia a primeira missão
  iniciarNovaMissao();
}

function esconderBotoesStart() {
  botaoStart.hide();
  botaoInstrucoes.hide();
}

function mostrarBotoesStart() {
  botaoStart.show();
  botaoInstrucoes.show();
}

function esconderBotoesIntroducao() {
  botaoPularIntroducao.hide();
}

function esconderBotoesCampo() {
  botaoIrCidade.hide();
}

function mostrarBotoesCidade() {
  botaoTrocar.show();
  // Atualiza o texto dos botões de melhoria para mostrar o custo atual
  botaoComprarMelhoriaCampo.html(`Melhorar Campo ($${100 * campoNivel})`);
  botaoComprarMelhoriaCidade.html(`Melhorar Cidade ($${150 * cidadeNivel})`);

  botaoComprarMelhoriaCampo.show();
  botaoComprarMelhoriaCidade.show();
  botaoComprarFerramentas.show();
  botaoComprarGasolina.show();
  botaoVoltar.show();
}

function esconderBotoesCidade() {
  botaoTrocar.hide();
  botaoComprarMelhoriaCampo.hide();
  botaoComprarMelhoriaCidade.hide();
  botaoComprarFerramentas.hide();
  botaoComprarGasolina.hide();
  botaoVoltar.hide();
}

// --- DRAW LOOP PRINCIPAL ---
function draw() {
  // background(245, 255, 250); // Fundo padrão - será sobrescrito pelas telas específicas

  if (tela === 'start') {
    telaStart();
  } else if (tela === 'introducao') {
    telaIntroducao();
  } else if (tela === 'instrucoes') {
    telaInstrucoes();
  } else if (tela === 'campo') {
    telaCampo();
  } else if (tela === 'cidade') {
    telaCidade();
  } else if (tela === 'gameover') {
    telaGameOver();
  } else if (tela === 'vitoria') {
    telaVitoria();
  }

  // Desenhar animações que podem aparecer em várias telas ou por cima de tudo
  if (animacaoColetaCidadeAtiva) {
    desenharAnimacaoColetaCidade();
  }
  if (animacaoNivelAtiva) {
    desenharAnimacaoNivel();
  }
}

// --- TELA START ---
function telaStart() {
  background(180, 220, 200); // Um verde mais suave para o fundo

  // Desenho de elementos para o campo (parte inferior)
  fill(100, 180, 90); // Grama
  rect(0, height * 0.7, width, height * 0.3);
  fill(120, 70, 10); // Troncos de árvores
  rect(width * 0.1, height * 0.6, 20, 70);
  rect(width * 0.4, height * 0.6, 20, 70);
  fill(50, 120, 30); // Folhas
  ellipse(width * 0.1 + 10, height * 0.6 - 20, 60, 80);
  ellipse(width * 0.4 + 10, height * 0.6 - 20, 60, 80);

  // Desenho de elementos para a cidade (parte superior)
  fill(135, 206, 250); // Céu
  rect(0, 0, width, height * 0.7);
  fill(150, 150, 180); // Prédio 1
  rect(width * 0.7, height * 0.4, 80, height * 0.3);
  fill(130, 130, 160); // Prédio 2
  rect(width * 0.85, height * 0.5, 60, height * 0.2);
  fill(255, 255, 150); // Janelas (amarelo claro)
  rect(width * 0.7 + 15, height * 0.45, 15, 20);
  rect(width * 0.7 + 45, height * 0.45, 15, 20);
  rect(width * 0.85 + 10, height * 0.55, 10, 15);

  // Título do jogo
  fill('#3B6253');
  textAlign(CENTER, CENTER);
  textSize(min(48, width / 15)); // Ajusta tamanho do texto para telas menores
  text('Festejando a Conexão', width / 2, height / 3 - 30);
  textSize(min(40, width / 18));
  text('Campo e Cidade', width / 2, height / 3 + 20);
}

// --- TELA INTRODUÇÃO ---
function reiniciarIntroducao() {
  introIndex = 0;
  introAlpha = 0;
  introFadeIn = true;
  introTimer = 0;
}

function telaIntroducao() {
  background(200, 220, 210);

  desenharPersonagensIntroducao();

  fill(0, introAlpha); // Texto fade in/out
  textAlign(CENTER, CENTER);
  textSize(min(28, width / 30)); // Ajusta tamanho do texto
  // Ajuste de largura e posição para evitar cortes
  text(introTexto[introIndex], width * 0.1, height * 0.25, width * 0.8);

  introTimer++;

  if (introFadeIn) {
    introAlpha += FADE_SPEED;
    if (introAlpha >= 255) {
      introAlpha = 255;
      introFadeIn = false;
      introTimer = 0;
    }
  } else {
    if (introTimer > INTRO_DURACAO_TEXTO) {
      introAlpha -= FADE_SPEED;
      if (introAlpha <= 0) {
        introAlpha = 0;
        introFadeIn = true;
        introTimer = 0;
        introIndex++;
        if (introIndex >= introTexto.length) {
          tela = 'campo';
          esconderBotoesIntroducao();
          resetJogo();
          botaoIrCidade.show();
        }
      }
    }
  }
}

function desenharPersonagensIntroducao() {
  // Cenário de fundo aprimorado
  fill(150, 200, 150); // Campo
  rect(0, height * 0.7, width / 2 + 50, height * 0.3); // Mais largo
  fill(180, 180, 200); // Cidade
  rect(width / 2 - 50, height * 0.7, width / 2 + 50, height * 0.3); // Mais largo

  // Árvores no campo da introdução
  fill(120, 70, 10); // Tronco
  rect(width / 4 - 30, height * 0.6, 20, 70);
  fill(50, 120, 30); // Folhas
  ellipse(width / 4 - 20, height * 0.6 - 20, 60, 80);

  // Prédios na cidade da introdução
  fill(150, 150, 180);
  rect(width * 0.75 - 40, height * 0.5, 80, height * 0.2); // Prédio central
  fill(255, 255, 150);
  rect(width * 0.75 - 25, height * 0.55, 15, 20); // Janelas
  rect(width * 0.75 + 10, height * 0.55, 15, 20);

  // Personagem do campo (fazendeiro)
  push();
  translate(width / 4, height * 0.7 + 30);
  // Roupa (macacão)
  fill(70, 130, 180); // Azul mais vibrante
  rect(-25, -35, 50, 60, 5);
  // Cinto
  fill(139, 69, 19);
  rect(-25, -10, 50, 8);
  // Cabeça
  fill(255, 220, 180);
  ellipse(0, -50, 30, 30);
  // Olhos
  fill(0);
  ellipse(-5, -55, 4, 4);
  ellipse(5, -55, 4, 4);
  // Boca
  arc(0, -45, 10, 5, 0, PI);
  // Chapéu de palha
  fill(220, 180, 80);
  ellipse(0, -65, 50, 20);
  fill(139, 69, 19);
  rect(-15, -70, 30, 10, 3);
  // Botas
  fill(100, 50, 0);
  rect(-20, 25, 15, 10);
  rect(5, 25, 15, 10);
  pop();

  // Personagem da cidade (cidadão/arquiteto)
  push();
  translate(width * 0.75, height * 0.7 + 30);
  // Roupa (camisa e calça)
  fill(50, 50, 150); // Azul escuro
  rect(-25, -35, 50, 60, 5);
  // Gravata
  fill(200, 0, 0);
  triangle(0, -25, -5, -15, 5, -15);
  // Cabeça
  fill(255, 220, 180);
  ellipse(0, -50, 30, 30);
  // Olhos
  fill(0);
  ellipse(-5, -55, 4, 4);
  ellipse(5, -55, 4, 4);
  // Boca
  line(-5, -45, 5, -45);
  // Cabelo
  fill(50, 50, 50);
  rect(-15, -65, 30, 10, 3);
  // Óculos
  noFill();
  stroke(0);
  strokeWeight(2);
  ellipse(-8, -55, 15, 10);
  ellipse(8, -55, 15, 10);
  line(-15, -55, 15, -55);
  noStroke();
  pop();

  // Conexão visual (linha tracejada)
  stroke(100);
  strokeWeight(2);
  drawingContext.setLineDash([5, 5]);
  line(width / 4, height * 0.75 + 10, width * 0.75, height * 0.75 + 10);
  drawingContext.setLineDash([]);
  noStroke();
}

// --- TELA INSTRUÇÕES ---
function telaInstrucoes() {
  background(230, 245, 235);
  fill('#2E4A3B');
  textAlign(LEFT, TOP);
  textSize(min(20, width / 40)); // Ajusta tamanho do texto
  let instr = `
**Objetivo do Jogo:**
- No campo, controle o trator com as **setas do teclado**.
- Colete **vegetais, frutas e madeira** para ganhar recursos.
- Evite **obstáculos** como agrotóxicos e pragas.
- Você tem **${vidas} vidas**. Se perder todas, o jogo acaba.
- **Ferramentas e Gasolina** são essenciais! Se acabarem, o jogo termina.
- Use o botão 'Ir para Cidade' para **trocar seus recursos por dinheiro** e comprar melhorias.
- Conforme avança, o campo e a cidade crescem e evoluem.
- **Campo e cidade dependem um do outro para prosperar.**

**Recursos:**
- **Vegetais, Frutas, Madeira**: Coletados no campo.
- **Dinheiro**: Ganho trocando recursos na cidade e usado para comprar melhorias e suprimentos.
- **Ferramentas e Gasolina**: Comprados na cidade para manter o trator funcionando.

**Melhorias na Cidade:**
- **Melhoria Campo**: Aumenta a velocidade do trator e a geração de recursos no campo.
- **Melhoria Cidade**: Aumenta os recursos coletados na cidade e a eficiência das trocas.

**Condição de Vitória:**
- Alcance o **Nível 5** tanto no Campo quanto na Cidade!

Boa sorte!`;

  // Ajusta a posição e largura do texto para melhor visualização
  text(instr, width * 0.07, height * 0.08, width * 0.86, height * 0.8);
}

// --- TELA CAMPO ---
function telaCampo() {
  // Ajusta o fundo com base no clima
  if (climaAtual === 'sol') {
    background(170, 220, 170); // Verde claro (seu fundo normal)
    // Adicionar brilho do sol, por exemplo:
    fill(255, 255, 0, 50); // Cor amarela semi-transparente
    ellipse(width - 100, 80, 150, 150); // Brilho em volta do sol
  } else { // Chuva
    background(130, 160, 130); // Verde mais escuro para chuva
    // Desenhar chuva:
    stroke(150, 180, 200, 150); // Cor da chuva
    strokeWeight(2);
    for (let i = 0; i < 100; i++) { // Desenha 100 linhas de chuva
      // Posições aleatórias para as gotas de chuva
      let x1 = random(width);
      let y1 = random(height);
      line(x1, y1, x1 + 5, y1 + 15); // Linhas inclinadas
    }
    noStroke();
  }

  desenharCampo();
  trator.mostrar();

  // Atualiza o clima
  atualizarClima();

  // Consumo de gasolina apenas se o trator estiver se movendo
  let isMoving = false;
  if (keyIsDown(LEFT_ARROW) || keyIsDown(RIGHT_ARROW) || keyIsDown(UP_ARROW) || keyIsDown(DOWN_ARROW)) {
    isMoving = true;
  }

  // Ajusta a velocidade do trator com base no clima
  let velocidadeTratorAtual = trator.vel;
  if (climaAtual === 'chuva') {
    velocidadeTratorAtual *= FATOR_CHUVA_TRATOR; // Trator mais lento
  }
  trator.mover(velocidadeTratorAtual); // Passa a velocidade ajustada para o trator

  if (isMoving && frameCount % 120 === 0) { // A cada 2 segundos (60 frames/seg * 2)
    gasolina--;
    if (gasolina < 0) {
      gasolina = 0;
      vidas = 0; // Trator para de funcionar sem gasolina
      tela = 'gameover';
    }
  }
  if (campoNivel > 1 && isMoving && frameCount % 180 === 0) { // Ferramentas são consumidas mais devagar e a partir do nível 2
    ferramentas--;
    if (ferramentas < 0) {
      ferramentas = 0;
      vidas = 0; // Trator para de funcionar sem ferramentas
      tela = 'gameover';
    }
  }

  // Mostrar coletáveis (agora fixos até serem coletados)
  for (let i = coletaveis.length - 1; i >= 0; i--) {
    coletaveis[i].mostrar();
    if (trator.colidiuCom(coletaveis[i])) {
      if (coletaveis[i].tipo === 'vida') { // Se for bônus de vida
        vidas++;
        somColeta.play();
      } else {
        recursos[coletaveis[i].tipo]++;
        somColeta.play();
        // Verifica se o coletável completa a missão
        if (missaoAtiva && coletaveis[i].tipo === tipoMissao) {
          quantidadeAtualMissao++;
          if (quantidadeAtualMissao >= quantidadeMissao) {
            // Missão Completa!
            recursos.dinheiro += recompensaMissao;
            mensagemMissao = `Missão COMPLETA! Você ganhou $${recompensaMissao}!`;
            missaoAtiva = false; // Desativa a missão atual
            setTimeout(iniciarNovaMissao, 3000); // Inicia nova missão após 3 segundos
          } else {
            mensagemMissao = `Missão: Coletar ${quantidadeAtualMissao}/${quantidadeMissao} ${tipoMissao}! Recompensa: $${recompensaMissao}`;
          }
        }
      }
      coletaveis.splice(i, 1);
    }
  }

  // Mostrar obstáculos
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    obstaculos[i].mostrar();
    obstaculos[i].mover();
    if (trator.colidiuCom(obstaculos[i])) {
      vidas--;
      somColisao.play();
      obstaculos.splice(i, 1);
      if (vidas <= 0) {
        tela = 'gameover';
        esconderBotoesCampo();
        botaoReiniciarJogo.show(); // Mostra o botão de reiniciar
      }
    } else if (obstaculos[i].x < -50) { // Remove obstáculos que saem da tela
      obstaculos.splice(i, 1);
    }
  }

  // Mostrar HUD (recursos e vidas) - Posição mais responsiva
  fill('#2E4A3B');
  textSize(min(18, width / 50)); // Ajusta tamanho do texto
  textAlign(LEFT, TOP);
  // Ajuste de posições para evitar cortes
  text(`Vidas: ${vidas}`, width * 0.02, height * 0.02);
  text(`Vegetais: ${recursos.vegetais}`, width * 0.02, height * 0.02 + 25);
  text(`Frutas: ${recursos.frutas}`, width * 0.02, height * 0.02 + 50);
  text(`Madeira: ${recursos.madeira}`, width * 0.02, height * 0.02 + 75);
  text(`Dinheiro: $${recursos.dinheiro}`, width * 0.02, height * 0.02 + 100);
  text(`Fase Campo: ${campoNivel}`, width * 0.02, height * 0.02 + 125);
  text(`Ferramentas: ${ferramentas}`, width * 0.02, height * 0.02 + 150);
  text(`Gasolina: ${gasolina}`, width * 0.02, height * 0.02 + 175);
  text(`Clima: ${climaAtual.toUpperCase()}`, width * 0.02, height * 0.02 + 200); // Exibe o clima

  // Exibir Missão Ativa - Posição mais responsiva e afastada do HUD principal
  if (missaoAtiva) {
    fill('#0A6640'); // Outra cor para a missão
    text(mensagemMissao, width * 0.02, height * 0.02 + 235);
  }

  botaoIrCidade.show();

  // Geração contínua de coletáveis se houver poucos na tela (para não sobrecarregar)
  let frequenciaColetavelReal = (70 - campoNivel * 3);
  if (climaAtual === 'sol') {
    frequenciaColetavelReal *= FATOR_SOL_COLETA; // Coletáveis aparecem mais rápido (intervalo menor)
  }
  if (coletaveis.length < 5 + campoNivel * 2) { // Aumenta a quantidade máxima de coletáveis no campo
    if (frameCount % floor(frequenciaColetavelReal) === 0) {
      gerarColetaveis();
    }
  }

  // Geração contínua de obstáculos
  if (obstaculos.length < maxObstaculos + campoNivel && frameCount % (300 - campoNivel * 5) === 0) { // Aparecem mais devagar
    gerarObstaculos();
  }

  // Checar condição de vitória
  if (campoNivel >= 5 && cidadeNivel >= 5) {
    tela = 'vitoria';
    esconderBotoesCampo();
    botaoReiniciarJogo.show();
  }
}

// --- TELA CIDADE ---
function telaCidade() {
  background(230, 230, 250); // lilás claro
  desenharCidade();
  fill('#2E2E4A');
  textSize(min(20, width / 40));
  textAlign(LEFT, TOP);

  // Informações do jogador - Posição mais responsiva
  text('Cidade em Crescimento!', width * 0.05, height * 0.05);
  text(`Cidade Nível: ${cidadeNivel}`, width * 0.05, height * 0.05 + 30);
  text(`Dinheiro: $${recursos.dinheiro}`, width * 0.05, height * 0.05 + 60);
  text(`Ferramentas: ${ferramentas}`, width * 0.05, height * 0.05 + 90);
  text(`Gasolina: ${gasolina}`, width * 0.05, height * 0.05 + 120);

  // Recursos para troca - Posição mais responsiva
  textAlign(RIGHT, TOP);
  textSize(min(18, width / 45));
  text('Seus recursos para troca:', width * 0.95, height * 0.05);
  text(`Vegetais: ${recursos.vegetais}`, width * 0.95, height * 0.05 + 30);
  text(`Frutas: ${recursos.frutas}`, width * 0.95, height * 0.05 + 60);
  text(`Madeira: ${recursos.madeira}`, width * 0.95, height * 0.05 + 90);

  // Mensagem de status centralizada (ÚNICA)
  fill('#2E4A3B');
  textSize(min(18, width / 45));
  textAlign(CENTER, TOP); // Alinha ao topo para começar a mensagem mais acima
  // Ajuste de posição para não sobrepor botões
  text(mensagemCidadeStatus, width / 2, height * 0.35, width * 0.7, 80);

  mostrarBotoesCidade();
}

function mousePressed() {
  // Nada para coletar na cidade com mouse, agora são botões
}

function iniciarAnimacaoColetaCidade(tipo, x, y) {
  animacaoColetaCidadeAtiva = true;
  tipoColetaCidade = tipo;
  coletavelCidadeX = x;
  coletavelCidadeY = y;
  animacaoColetaCidadeTimer = DURACAO_ANIMACAO_COLETA;
}

function desenharAnimacaoColetaCidade() {
  if (animacaoColetaCidadeTimer > 0) {
    let alpha = map(animacaoColetaCidadeTimer, DURACAO_ANIMACAO_COLETA, 0, 255, 0);
    fill(0, 200, 0, alpha);
    textSize(24);
    textAlign(CENTER, CENTER);
    text('+Dinheiro!', coletavelCidadeX, coletavelCidadeY - (DURACAO_ANIMACAO_COLETA - animacaoColetaCidadeTimer));
    animacaoColetaCidadeTimer--;
  } else {
    animacaoColetaCidadeAtiva = false;
  }
}

// --- TELA GAME OVER ---
function telaGameOver() {
  background(180, 50, 50);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(min(50, width / 15));
  text('Game Over', width / 2, height / 3);
  textSize(min(22, width / 35));
  text('Você perdeu todas as vidas!', width / 2, height / 2 - 20);
  textSize(min(18, width / 40));
  text('O trator parou de funcionar.', width / 2, height / 2 + 10);
  botaoReiniciarJogo.show();
}

// --- TELA VITÓRIA ---
function telaVitoria() {
  background(150, 220, 180); // Um verde mais alegre
  fill(50, 100, 70);
  textAlign(CENTER, CENTER);
  textSize(min(50, width / 15));
  text('PARABÉNS!', width / 2, height / 3);
  textSize(min(30, width / 25));
  text('Você conectou o Campo e a Cidade!', width / 2, height / 2 - 20);
  textSize(min(22, width / 35));
  text('O Vale Verde prospera graças a você!', width / 2, height / 2 + 20);
  botaoReiniciarJogo.show();
}

// --- FUNÇÕES PARA DESENHAR ELEMENTOS DE CENÁRIO ---
function desenharCampo() {
  // Céu
  fill(135, 206, 235);
  rect(0, 0, width, height * 0.4);

  // Sol
  fill(255, 200, 0);
  ellipse(width - 100, 80, 80, 80);

  // Montanhas
  fill(100, 150, 100);
  triangle(0, height * 0.4, width * 0.2, height * 0.2, width * 0.4, height * 0.4);
  triangle(width * 0.3, height * 0.4, width * 0.5, height * 0.1, width * 0.7, height * 0.4);
  triangle(width * 0.6, height * 0.4, width * 0.8, height * 0.25, width, height * 0.4);

  // Grama que aumenta com o nível do campo
  noStroke();
  fill(100, 180, 90);
  let gramaAlturaVisual = map(campoNivel, 1, 10, height * 0.6, height * 0.8); // Aumenta a altura da grama visivelmente
  rect(0, height - gramaAlturaVisual, width, gramaAlturaVisual);

  // Linhas de plantio (visual aprimorado)
  stroke(70, 120, 60);
  strokeWeight(2);
  for (let y = height * 0.7; y < height; y += 20) {
    line(0, y, width, y);
  }
  noStroke();

  // árvores
  for (let i = width * 0.05; i < width; i += width * 0.15) { // Posição relativa
    fill(120, 70, 10); // Tronco
    rect(i - 10, height * 0.5 - 20, 20, 70);
    fill(50, 120, 30); // Folhas
    ellipse(i, height * 0.5 - 30, 60, 80);
    ellipse(i - 20, height * 0.5 - 40, 50, 60);
    ellipse(i + 20, height * 0.5 - 40, 50, 60);
  }
}

function desenharCidade() {
  // Céu
  fill(135, 206, 250);
  rect(0, 0, width, height * 0.4);

  // Rua
  fill(100);
  rect(0, height * 0.8, width, height * 0.2);
  fill(255, 200, 0); // Linhas da rua
  for (let x = 20; x < width; x += 40) {
    rect(x, height * 0.8 + 10, 20, 5);
  }

  // Prédios simples que aumentam com o nível da cidade
  let baseX = width * 0.05; // Começa mais à esquerda
  let baseY = height * 0.8; // Prédios começam na rua
  for (let i = 0; i < cidadeNivel + 2; i++) {
    let buildingHeight = height * 0.15 + i * (height * 0.03); // Altura responsiva
    let buildingWidth = width * 0.1; // Largura responsiva
    let buildingColor = color(150 + i * 10, 150 + i * 5, 200);
    fill(buildingColor);
    rect(baseX + i * (buildingWidth + 20), baseY - buildingHeight, buildingWidth, buildingHeight); // Prédio

    // Janelas
    fill(255, 255, 150, 200); // Amarelo claro para as janelas
    let windowWidth = buildingWidth * 0.25;
    let windowHeight = buildingHeight * 0.15;
    for (let j = 0; j < floor(buildingHeight / (windowHeight + 10)); j++) {
      if (j * (windowHeight + 10) + windowHeight + 10 > buildingHeight) continue; // Evita janelas cortadas
      rect(baseX + i * (buildingWidth + 20) + buildingWidth * 0.15, baseY - buildingHeight + 10 + j * (windowHeight + 10), windowWidth, windowHeight);
      rect(baseX + i * (buildingWidth + 20) + buildingWidth * 0.85 - windowWidth, baseY - buildingHeight + 10 + j * (windowHeight + 10), windowWidth, windowHeight);
    }

    // Telhado
    fill(80);
    rect(baseX + i * (buildingWidth + 20), baseY - buildingHeight - 10, buildingWidth, 10);
  }
}

// --- CLASSES DO JOGO ---
class Trator {
  constructor() {
    this.w = width * 0.06; // Largura responsiva
    this.h = height * 0.06; // Altura responsiva
    this.x = width / 2 - this.w / 2;
    this.y = height * 0.75 - this.h; // Começa na linha da grama
    this.vel = 5 + campoNivel * 0.5; // Aumenta a velocidade com o nível do campo
  }
  mostrar() {
    push(); // Salva o estado atual do desenho
    translate(this.x, this.y);

    // Corpo do trator
    fill('#D35400'); // Laranja forte
    rect(0, 0, this.w, this.h, 8);

    // Rodas
    fill('#4D3426'); // Marrom escuro
    ellipse(this.w * 0.2, this.h, this.w * 0.5, this.w * 0.5); // Roda traseira
    ellipse(this.w * 0.8, this.h, this.w * 0.5, this.w * 0.5); // Roda dianteira

    // Cabine
    fill('#E67E22'); // Laranja mais claro
    rect(this.w * 0.2, -this.h * 0.5, this.w / 2, this.h * 0.6, 5);

    // Para-choque (opcional)
    fill('#8A4C2E');
    rect(-5, 5, 10, this.h - 10, 3);
    rect(this.w - 5, 5, 10, this.h - 10, 3);

    pop(); // Restaura o estado anterior do desenho
  }
  mover(velocidadeAtual) { // Recebe a velocidade como parâmetro
    let gramaMinY = height * 0.4 + height * 0.05; // Ajusta a área jogável para evitar sobreposição
    let tratorMaxY = height - this.h - height * 0.02; // Não deixa o trator ir até o final da tela

    if (keyIsDown(LEFT_ARROW) && this.x > 0) {
      this.x -= velocidadeAtual; // Usa a velocidade recebida
    }
    if (keyIsDown(RIGHT_ARROW) && this.x + this.w < width) {
      this.x += velocidadeAtual;
    }
    if (keyIsDown(UP_ARROW) && this.y > gramaMinY) {
      this.y -= velocidadeAtual;
    }
    if (keyIsDown(DOWN_ARROW) && this.y < tratorMaxY) {
      this.y += velocidadeAtual;
    }

    this.x = constrain(this.x, 0, width - this.w);
    this.y = constrain(this.y, gramaMinY, tratorMaxY);
  }
  colidiuCom(obj) {
    return !(
      this.x + this.w < obj.x ||
      this.x > obj.x + obj.w ||
      this.y + this.h < obj.y ||
      this.y > obj.y + obj.h
    );
  }
}

class Coletavel {
  constructor(tipo) {
    this.tipo = tipo;
    this.w = width * 0.035; // Tamanho responsivo
    this.h = this.w; // Proporcional
    this.x = random(width * 0.1, width * 0.9); // Posição X aleatória dentro da tela
    let gramaMinY = height * 0.4 + height * 0.05; // Começa um pouco abaixo do céu para evitar sobreposição
    let gramaMaxY = height - this.h - height * 0.02; // Não vai até o final
    this.y = random(gramaMinY, gramaMaxY); // Posição Y aleatória dentro da grama
    this.vel = 0; // Coletáveis são fixos
  }
  mostrar() {
    push();
    translate(this.x, this.y);
    if (this.tipo === 'vegetais') {
      fill('#4CAF50'); // Verde vibrante
      ellipse(this.w / 2, this.h / 2, this.w * 0.8, this.h * 0.8);
      fill('#388E3C'); // Verde mais escuro para detalhes
      triangle(this.w / 2, 0, this.w * 0.2, this.h * 0.3, this.w * 0.8, this.h * 0.3); // Folhas
      rect(this.w * 0.45, this.h * 0.5, this.w * 0.1, this.h * 0.25, 2); // Talo
    } else if (this.tipo === 'frutas') {
      fill('#FF7043'); // Laranja avermelhado
      ellipse(this.w / 2, this.h / 2, this.w * 0.8, this.h * 0.8);
      fill('#BF360C'); // Cereja / Talinho
      ellipse(this.w * 0.3, this.h * 0.3, this.w * 0.3, this.h * 0.3);
      line(this.w * 0.3, this.h * 0.3, this.w * 0.5, this.h * 0.1);
    } else if (this.tipo === 'madeira') {
      fill('#6D4C41'); // Marrom madeira
      rect(this.w * 0.15, this.h * 0.3, this.w * 0.7, this.h * 0.3, 3);
      rect(this.w * 0.3, this.h * 0.15, this.w * 0.4, this.h * 0.7, 3);
      stroke(90, 60, 50); // Detalhes da madeira
      line(this.w * 0.25, this.h * 0.45, this.w * 0.75, this.h * 0.45);
      line(this.w * 0.45, this.h * 0.25, this.w * 0.45, this.h * 0.75);
    } else if (this.tipo === 'vida') { // Desenho para o bônus de vida (coração)
      fill('#FF0000'); // Vermelho
      // Metades de coração
      ellipse(this.w * 0.35, this.h * 0.3, this.w * 0.6, this.h * 0.6);
      ellipse(this.w * 0.65, this.h * 0.3, this.w * 0.6, this.h * 0.6);
      triangle(this.w * 0.05, this.h * 0.5, this.w * 0.95, this.h * 0.5, this.w * 0.5, this.h * 0.95);
    }
    pop();
  }
  mover() {
    // Coletáveis não se movem mais
  }
}

class Obstaculo {
  constructor(tipo) {
    this.tipo = tipo;
    this.w = width * 0.04; // Tamanho responsivo
    this.h = this.w; // Proporcional
    this.x = random(width, width + 300); // Obstáculos ainda vêm da direita
    let gramaMinY = height * 0.4 + height * 0.05;
    let gramaMaxY = height - this.h - height * 0.02;
    this.y = random(gramaMinY, gramaMaxY);
    this.vel = 2 + campoNivel * 0.2; // Velocidade aumenta com o nível do campo
  }
  mostrar() {
    push();
    translate(this.x, this.y);
    if (this.tipo === 'agrotoxicos') {
      fill('#9E2A2B'); // Vermelho escuro
      rect(0, 0, this.w, this.h, 6);
      fill('#6B0000');
      textSize(this.w * 0.5);
      textAlign(CENTER, CENTER);
      text('!', this.w / 2, this.h / 2); // Ponto de exclamação
      fill(255); // Caveira (opcional)
      ellipse(this.w / 2, this.h * 0.3, this.w * 0.3, this.h * 0.3);
      rect(this.w * 0.35, this.h * 0.5, this.w * 0.3, this.h * 0.15);
    } else if (this.tipo === 'pragas') {
      fill('#755C48'); // Marrom para o corpo da praga
      ellipse(this.w / 2, this.h / 2, this.w * 0.8, this.h * 0.6);
      fill('#3E2723'); // Detalhes
      ellipse(this.w * 0.35, this.h / 2, this.w * 0.15, this.h * 0.3);
      ellipse(this.w * 0.65, this.h / 2, this.w * 0.15, this.h * 0.3);
      line(this.w / 2, this.h * 0.2, this.w * 0.35, this.h * 0.05); // Antenas
      line(this.w / 2, this.h * 0.2, this.w * 0.65, this.h * 0.05);
    }
    pop();
  }
  mover() {
    this.x -= this.vel;
  }
}

// --- FUNÇÕES PARA GERAR COLETÁVEIS E OBSTÁCULOS ---
function gerarColetaveis() {
  let tipos = ['vegetais', 'frutas', 'madeira'];
  // Chance de gerar bônus de vida (1 em 15, menor que antes)
  if (random(1) < 0.06) { // Aproximadamente 6% de chance
    tipos.push('vida');
  }
  let tipo = random(tipos);
  coletaveis.push(new Coletavel(tipo));
}

function gerarObstaculos() {
  let tipos = ['agrotoxicos', 'pragas'];
  let tipo = random(tipos);
  obstaculos.push(new Obstaculo(tipo));
}

// --- FUNÇÃO PARA TROCAR RECURSOS NA CIDADE ---
function trocarRecursos() {
  let valorVegetal = 2 * cidadeNivel;
  let valorFruta = 3 * cidadeNivel;
  let valorMadeira = 4 * cidadeNivel;

  let dinheiroGanho = (recursos.vegetais * valorVegetal) + (recursos.frutas * valorFruta) + (recursos.madeira * valorMadeira);

  if (dinheiroGanho > 0) {
    recursos.dinheiro += dinheiroGanho;
    recursos.vegetais = 0;
    recursos.frutas = 0;
    recursos.madeira = 0;
    mensagemCidadeStatus = `Você trocou seus recursos e ganhou $${dinheiroGanho}!`;
    somCompra.play(); // Som de compra/transação
    iniciarAnimacaoColetaCidade('dinheiro', width / 2, height / 2);
  } else {
    mensagemCidadeStatus = 'Você não tem recursos para trocar.';
  }
}

// --- FUNÇÕES PARA COMPRAR MELHORIAS ---
function comprarMelhoria(tipo) {
  if (tipo === 'campo') {
    let custo = 100 * campoNivel;
    if (recursos.dinheiro >= custo) {
      recursos.dinheiro -= custo;
      campoNivel++;
      mensagemCidadeStatus = `Melhoria no campo aplicada! Campo Nível: ${campoNivel}. Próxima melhoria custará $${100 * (campoNivel + 1)}.`;
      trator.vel = 5 + campoNivel * 0.5; // Atualiza velocidade do trator
      somCompra.play();

      // Ativar Animação Nível UP Campo
      animacaoNivelAtiva = true;
      animacaoNivelTexto = `Campo Nível ${campoNivel}!`;
      animacaoNivelAlpha = 255;
      animacaoNivelTimer = DURACAO_ANIMACAO_NIVEL;
    } else {
      mensagemCidadeStatus = `Dinheiro insuficiente para melhorar o campo. Você precisa de $${custo}.`;
    }
  } else if (tipo === 'cidade') {
    let custo = 150 * cidadeNivel;
    if (recursos.dinheiro >= custo) {
      recursos.dinheiro -= custo;
      cidadeNivel++;
      mensagemCidadeStatus = `Melhoria na cidade aplicada! Cidade Nível: ${cidadeNivel}. Próxima melhoria custará $${150 * (cidadeNivel + 1)}.`;
      somCompra.play();

      // Ativar Animação Nível UP Cidade
      animacaoNivelAtiva = true;
      animacaoNivelTexto = `Cidade Nível ${cidadeNivel}!`;
      animacaoNivelAlpha = 255;
      animacaoNivelTimer = DURACAO_ANIMACAO_NIVEL;
    } else {
      mensagemCidadeStatus = `Dinheiro insuficiente para melhorar a cidade. Você precisa de $${custo}.`;
    }
  }
  // Atualiza o texto dos botões após a compra (ou tentativa)
  mostrarBotoesCidade();
}

// --- FUNÇÕES PARA COMPRAR SUPRIMENTOS ---
function comprarSuprimento(suprimento) {
  if (suprimento === 'ferramentas') {
    if (recursos.dinheiro >= CUSTO_FERRAMENTA) {
      recursos.dinheiro -= CUSTO_FERRAMENTA;
      ferramentas += 5; // Adiciona 5 ferramentas
      mensagemCidadeStatus = `Você comprou 5 ferramentas por $${CUSTO_FERRAMENTA}!`;
      somCompra.play();
      iniciarAnimacaoColetaCidade('ferramentas', botaoComprarFerramentas.x + botaoComprarFerramentas.width / 2, botaoComprarFerramentas.y);
    } else {
      mensagemCidadeStatus = `Dinheiro insuficiente para comprar ferramentas. Você precisa de $${CUSTO_FERRAMENTA}.`;
    }
  } else if (suprimento === 'gasolina') {
    if (recursos.dinheiro >= CUSTO_GASOLINA) {
      recursos.dinheiro -= CUSTO_GASOLINA;
      gasolina += 10; // Adiciona 10 de gasolina
      mensagemCidadeStatus = `Você comprou 10 de gasolina por $${CUSTO_GASOLINA}!`;
      somCompra.play();
      iniciarAnimacaoColetaCidade('gasolina', botaoComprarGasolina.x + botaoComprarGasolina.width / 2, botaoComprarGasolina.y);
    } else {
      mensagemCidadeStatus = `Dinheiro insuficiente para comprar gasolina. Você precisa de $${CUSTO_GASOLINA}.`;
    }
  }
}

// --- FUNÇÃO PARA ATUALIZAR O CLIMA ---
function atualizarClima() {
  timerClima++;
  if (timerClima >= DURACAO_CLIMA) {
    timerClima = 0;
    if (climaAtual === 'sol') {
      climaAtual = 'chuva';
    } else {
      climaAtual = 'sol';
    }
    // Você pode adicionar uma notificação visual ou sonora para a mudança de clima, se quiser
  }
}

// --- FUNÇÃO PARA ANIMAR NÍVEL UP ---
function desenharAnimacaoNivel() {
  if (animacaoNivelAtiva) {
    let yPos = map(animacaoNivelTimer, DURACAO_ANIMACAO_NIVEL, 0, height / 2 - 50, height / 2 - 100); // Sobe um pouco
    let alpha = map(animacaoNivelTimer, DURACAO_ANIMACAO_NIVEL, 0, 255, 0); // Desaparece

    push();
    textAlign(CENTER, CENTER);
    textSize(min(40, width / 20));
    fill(255, 255, 0, alpha); // Amarelo brilhante
    text(animacaoNivelTexto, width / 2, yPos);
    pop();

    animacaoNivelTimer--;
    if (animacaoNivelTimer <= 0) {
      animacaoNivelAtiva = false;
    }
  }
}

// --- FUNÇÃO PARA INICIAR NOVA MISSÃO ---
function iniciarNovaMissao() {
  let tiposRecurso = ['vegetais', 'frutas', 'madeira'];
  tipoMissao = random(tiposRecurso);
  quantidadeMissao = 5 + campoNivel * 2; // Aumenta a dificuldade da missão com o nível
  quantidadeAtualMissao = 0;
  recompensaMissao = 50 + campoNivel * 10; // Recompensa em dinheiro

  mensagemMissao = `Missão: Coletar ${quantidadeAtualMissao}/${quantidadeMissao} ${tipoMissao}! Recompensa: $${recompensaMissao}`;
  missaoAtiva = true;
}